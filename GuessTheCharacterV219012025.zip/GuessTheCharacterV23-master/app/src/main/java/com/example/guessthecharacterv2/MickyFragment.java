package com.example.guessthecharacterv2;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link MickyFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class MickyFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

//this code is the entire game's logic for the level of micky

    Button button1;
    Button button2;
    Button button3;
    Button button4;
    Button button5;
    Button button6;
    Button StartButton;
    ImageView CheckImageButton;
    ImageView RestartButton;

    ImageView GoBackButton;

    View view;

    TextView textView1;
    TextView textView2;
    TextView textView3;
    TextView textView4;
    TextView textView5;
    int counterOfDigit = 0;

    Boolean Button1Used = false;
    Boolean Button2Used = false;
    Boolean Button3Used = false;
    Boolean Button4Used = false;
    Boolean Button5Used = false;
    Boolean Button6Used = false;


    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public MickyFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment MickyFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static MickyFragment newInstance(String param1, String param2) {
        MickyFragment fragment = new MickyFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {


        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_micky, container, false);
        String[] alphabet = {"a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"};
        char[] micky = {'m', 'i', 'c', 'k', 'y'};
        String[] answer = {"m", "i", "c", "k", "y"};




        button1 = view.findViewById(R.id.button1);
        button2 = view.findViewById(R.id.button2);
        button3 = view.findViewById(R.id.button3);
        button4 = view.findViewById(R.id.button4);
        button5 = view.findViewById(R.id.button5);
        button6 = view.findViewById(R.id.button6);

        GoBackButton = view.findViewById(R.id.GoBackButton);
        CheckImageButton = view.findViewById(R.id.CheckImageButton);
        RestartButton = view.findViewById(R.id.RestartButton);

        textView1 = view.findViewById(R.id.textView1);
        textView2 = view.findViewById(R.id.textView2);
        textView3 = view.findViewById(R.id.textView3);
        textView4 = view.findViewById(R.id.textView4);
        textView5 = view.findViewById(R.id.textView5);

        int counter1 = 0;
        int counter2 = 0;
        int counter3 = 0;
        int counter4 = 0;
        int counter5 = 0;
        int counter6 = 0;
        int sum = 0;
        //randomize all the letters
        int letter = (int) (Math.random() * alphabet.length);
        button1.setText(String.valueOf(alphabet[letter]));
        letter = (int) (Math.random() * alphabet.length);
        button2.setText(String.valueOf(alphabet[letter]));
        letter = (int) (Math.random() * alphabet.length);
        button3.setText(String.valueOf(alphabet[letter]));
        letter = (int) (Math.random() * alphabet.length);
        button4.setText(String.valueOf(alphabet[letter]));
        letter = (int) (Math.random() * alphabet.length);
        button5.setText(String.valueOf(alphabet[letter]));
        letter = (int) (Math.random() * alphabet.length);
        button6.setText(String.valueOf(alphabet[letter]));
        //go back to the levels fragment
        GoBackButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    Intent intent = new Intent(getActivity(), ChooseLevel.class);
                    startActivity(intent);
            }
        });

        //enters all the letters of micky in random order to the buttons
        while (sum != 5) {

            int buttonNumber = (int) (Math.random() * 6) + 1;

            switch (buttonNumber) {
                case 1:
                    if (counter1 == 0) {
                        button1.setText(String.valueOf(micky[sum]));
                        counter1++;
                        sum++;
                    }
                    break;
                case 2:
                    if (counter2 == 0) {
                        button2.setText(String.valueOf(micky[sum]));
                        counter2++;
                        sum++;
                    }
                    break;
                case 3:
                    if (counter3 == 0) {
                        button3.setText(String.valueOf(micky[sum]));
                        counter3++;
                        sum++;
                    }
                    break;
                case 4:
                    if (counter4 == 0) {
                        button4.setText(String.valueOf(micky[sum]));
                        counter4++;
                        sum++;
                    }

                    break;
                case 5:
                    if (counter5 == 0) {
                        button5.setText(String.valueOf(micky[sum]));
                        counter5++;
                        sum++;
                    }
                    ;

                    break;
                case 6:
                    if (counter6 == 0) {
                        button6.setText(String.valueOf(micky[sum]));
                        counter6++;
                        sum++;
                    }
                    break;
            }


        }

        String[] userAnswer = new String[5];
        //first button, it adds the letter on it to the the array of UserAnswer and it puts the letter on the text view depends on the order it was clicked
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String buttonText1 = button1.getText().toString();

                if (counterOfDigit == 5) {

                    Toast.makeText(getContext(), "You chose the maximum amount of letters!", Toast.LENGTH_SHORT).show();
                } else if (Button1Used) {
                    Toast.makeText(getContext(), "Can't choose the same letter twice!", Toast.LENGTH_SHORT).show();
                }

                if (counterOfDigit < 5 && !Button1Used) {
                    userAnswer[counterOfDigit] = buttonText1;
                    Button1Used = true;
                    switch (counterOfDigit) {
                        case 0:
                            textView1.setText(String.valueOf(userAnswer[counterOfDigit]));
                            break;
                        case 1:
                            textView2.setText(String.valueOf(userAnswer[counterOfDigit]));
                            break;
                        case 2:
                            textView3.setText(String.valueOf(userAnswer[counterOfDigit]));
                            break;
                        case 3:
                            textView4.setText(String.valueOf(userAnswer[counterOfDigit]));
                            break;
                        case 4:
                            textView5.setText(String.valueOf(userAnswer[counterOfDigit]));
                            break;
                    }


                    counterOfDigit++;
                }




            }
        });
        //second button, it adds the letter on it to the the array of UserAnswer and it puts the letter on the text view depends on the order it was clicked

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (counterOfDigit == 5) {
                    Toast.makeText(getContext(), "You chose the maximum amount of letters!", Toast.LENGTH_SHORT).show();
                } else if (Button2Used) {
                    Toast.makeText(getContext(), "Can't choose the same letter twice!", Toast.LENGTH_SHORT).show();
                }

                String buttonText2 = button2.getText().toString();
                if (counterOfDigit < 5 && !Button2Used) {
                    userAnswer[counterOfDigit] = buttonText2;
                    Button2Used = true;

                    switch (counterOfDigit) {
                        case 0:
                            textView1.setText(String.valueOf(userAnswer[counterOfDigit]));
                            break;
                        case 1:
                            textView2.setText(String.valueOf(userAnswer[counterOfDigit]));
                            break;
                        case 2:
                            textView3.setText(String.valueOf(userAnswer[counterOfDigit]));
                            break;
                        case 3:
                            textView4.setText(String.valueOf(userAnswer[counterOfDigit]));
                            break;
                        case 4:
                            textView5.setText(String.valueOf(userAnswer[counterOfDigit]));
                            break;
                    }

                    counterOfDigit++;
                }



            }
        });
        //third button, it adds the letter on it to the the array of UserAnswer and it puts the letter on the text view depends on the order it was clicked

        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (counterOfDigit == 5) {
                    Toast.makeText(getContext(), "You chose the maximum amount of letters!", Toast.LENGTH_SHORT).show();
                } else if (Button3Used) {
                    Toast.makeText(getContext(), "Can't choose the same letter twice!", Toast.LENGTH_SHORT).show();
                }

                if (counterOfDigit < 5 && !Button3Used) {
                    String buttonText3 = button3.getText().toString();
                    userAnswer[counterOfDigit] = buttonText3;
                    Button3Used = true;
                    switch (counterOfDigit) {
                        case 0:
                            textView1.setText(String.valueOf(userAnswer[counterOfDigit]));
                            break;
                        case 1:
                            textView2.setText(String.valueOf(userAnswer[counterOfDigit]));
                            break;
                        case 2:
                            textView3.setText(String.valueOf(userAnswer[counterOfDigit]));
                            break;
                        case 3:
                            textView4.setText(String.valueOf(userAnswer[counterOfDigit]));
                            break;
                        case 4:
                            textView5.setText(String.valueOf(userAnswer[counterOfDigit]));
                            break;
                    }

                    counterOfDigit++;
                }



            }
        });
        //fourth button, it adds the letter on it to the the array of UserAnswer and it puts the letter on the text view depends on the order it was clicked

        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String buttonText4 = button4.getText().toString();

                if (counterOfDigit == 5) {
                    Toast.makeText(getContext(), "You chose the maximum amount of letters!", Toast.LENGTH_SHORT).show();
                } else if (Button4Used) {
                    Toast.makeText(getContext(), "Can't choose the same letter twice!", Toast.LENGTH_SHORT).show();
                }

                if (counterOfDigit < 5 && !Button4Used) {
                    userAnswer[counterOfDigit] = buttonText4;
                    Button4Used = true;


                    switch (counterOfDigit) {
                        case 0:
                            textView1.setText(String.valueOf(userAnswer[counterOfDigit]));
                            break;
                        case 1:
                            textView2.setText(String.valueOf(userAnswer[counterOfDigit]));
                            break;
                        case 2:
                            textView3.setText(String.valueOf(userAnswer[counterOfDigit]));
                            break;
                        case 3:
                            textView4.setText(String.valueOf(userAnswer[counterOfDigit]));
                            break;
                        case 4:
                            textView5.setText(String.valueOf(userAnswer[counterOfDigit]));
                            break;
                    }

                    counterOfDigit++;
                }



            }
        });
        //fifth button, it adds the letter on it to the the array of UserAnswer and it puts the letter on the text view depends on the order it was clicked

        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String buttonText5 = button5.getText().toString();

                if (counterOfDigit == 5) {
                    Toast.makeText(getContext(), "You chose the maximum amount of letters!", Toast.LENGTH_SHORT).show();
                } else if (Button5Used) {
                    Toast.makeText(getContext(), "Can't choose the same letter twice!", Toast.LENGTH_SHORT).show();
                }

                if (counterOfDigit < 5 && !Button5Used) {
                    userAnswer[counterOfDigit] = buttonText5;
                    Button5Used = true;

                    switch (counterOfDigit) {
                        case 0:
                            textView1.setText(String.valueOf(userAnswer[counterOfDigit]));
                            break;
                        case 1:
                            textView2.setText(String.valueOf(userAnswer[counterOfDigit]));
                            break;
                        case 2:
                            textView3.setText(String.valueOf(userAnswer[counterOfDigit]));
                            break;
                        case 3:
                            textView4.setText(String.valueOf(userAnswer[counterOfDigit]));
                            break;
                        case 4:
                            textView5.setText(String.valueOf(userAnswer[counterOfDigit]));
                            break;
                    }

                    counterOfDigit++;
                }



            }
        });
        //sixth button, it adds the letter on it to the the array of UserAnswer and it puts the letter on the text view depends on the order it was clicked

        button6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String buttonText6 = button6.getText().toString();
                if (counterOfDigit == 5) {
                    Toast.makeText(getContext(), "You chose the maximum amount of letters!", Toast.LENGTH_SHORT).show();
                } else if (Button6Used) {
                    Toast.makeText(getContext(), "Can't choose the same letter twice!", Toast.LENGTH_SHORT).show();
                }

                if (counterOfDigit < 5 && !Button6Used) {
                    userAnswer[counterOfDigit] = buttonText6;
                    Button6Used = true;

                    switch (counterOfDigit) {
                        case 0:
                            textView1.setText(String.valueOf(userAnswer[counterOfDigit]));
                            break;
                        case 1:
                            textView2.setText(String.valueOf(userAnswer[counterOfDigit]));
                            break;
                        case 2:
                            textView3.setText(String.valueOf(userAnswer[counterOfDigit]));
                            break;
                        case 3:
                            textView4.setText(String.valueOf(userAnswer[counterOfDigit]));
                            break;
                        case 4:
                            textView5.setText(String.valueOf(userAnswer[counterOfDigit]));
                            break;
                    }

                    counterOfDigit++;
                }


            }
        });
        //checks the user is correct, if correct, go to correct fragment, if wrong, go to wrong fragment
        CheckImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(counterOfDigit == 5) {

                    int countOfCorrect = 0;
                    for (int i = 0; i <= 4; i++) {
                        if (userAnswer[i].equals(answer[i])) {
                            countOfCorrect++;
                        }

                    }
                    FragmentTransaction transaction = getParentFragmentManager().beginTransaction();

                    if (countOfCorrect == 5) {

                        transaction.replace(R.id.fragment_container1, new CorrectFragment());
                        transaction.addToBackStack(null);
                        transaction.commit();
                    } else {


                        transaction.replace(R.id.fragment_container1, new WrongFragment());
                        transaction.addToBackStack(null);
                        transaction.commit();
                    }


                } else {

                    Toast.makeText(getContext(), "You need to choose 5 letters!", Toast.LENGTH_SHORT).show();
                }

            }
        });
        //reset all the letters which the user clicked, resets the text views and the array of UserAnswer
        RestartButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Button1Used = false;
                Button2Used = false;
                Button3Used = false;
                Button4Used = false;
                Button5Used = false;
                Button6Used = false;

                counterOfDigit = 0;


                textView1.setText("-");
                textView2.setText("-");
                textView3.setText("-");
                textView4.setText("-");
                textView5.setText("-");

            }
        });






        return view;
    }
}