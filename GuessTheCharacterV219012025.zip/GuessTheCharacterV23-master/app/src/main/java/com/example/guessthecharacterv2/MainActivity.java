package com.example.guessthecharacterv2;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.os.CountDownTimer;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;

//this activity is for welcoming the user
public class MainActivity extends AppCompatActivity {

    Button MainButton;
    CountDownTimer AutoCdt;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        //if user doesn't click the button in 15 seconds, it will go to login screen
        AutoCdt = new CountDownTimer(15000, 1000) {

            public void onTick(long millisUntilFinished) {


            }

            public void onFinish() {

                Intent autoIntent = new Intent( MainActivity.this , Login.class);
                startActivity(autoIntent);

            }
        }.start();

        MainButton = findViewById(R.id.MainButton);
        //main button to go to login screen
        MainButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {

                Intent intent = new Intent( MainActivity.this , Login.class);

                startActivity(intent);
            }});










    }



}