package com.example.guessthecharacterv2;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
//this activity is a guide for the user to understand the game

public class GuideScreen extends AppCompatActivity {
    Button ttsButton;
    Button GoBackButton;
    Context context;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_guide_screen);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);



            return insets;
        });

        initialize();
        //if clicked, ai will speak all the the rules to understand the game.
        ttsButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                saySomething("Step 1 - Choose a level by click a picture." + "Step 2 - Look at the picture and think who is in the picture." + "Step 3 - Guess the character's name by clicking the buttons of the letters in order you think is right." + "Step 4 - After you fill all the empty slots for the character name, click the check mark button to check if you are right." + "additional rules:" + "- Can't pick the same letter twice." + "- You have to fill all the empty slots to check if you are right." + "- Have fun!");

            }
        });
        //if clicked, it will go back to the choose level screen (levels fragment)
        GoBackButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent( GuideScreen.this , ChooseLevel.class);

                startActivity(intent);
            }
        });

    }

    //method to start the text to speech service
    public void saySomething(String text){

        Intent intent = new Intent(context, TextToSpeechService.class);
        intent.putExtra("text", text);
        startService(intent);
    }

    //init all elements
    public void initialize(){
        context = this;
        ttsButton = findViewById(R.id.ttsButton);
        GoBackButton = findViewById(R.id.GoBackButton);


    }
}